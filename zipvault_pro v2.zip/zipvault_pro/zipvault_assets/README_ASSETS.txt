ZipVault Pro assets required for EXE build.
